# Inferelator with just regression (no TFA)
# no gold standard 

from pathlib import Path
import pandas as pd
import inferelator

# --------------------------------------------------
# Paths
# --------------------------------------------------

DATA_DIR = Path("../data")
OUT_DIR = Path("../results")
OUT_DIR.mkdir(exist_ok=True)

# --------------------------------------------------
# Create workflow (IMPORTANT: your actual class)
# --------------------------------------------------

worker = inferelator.inferelator_workflow(
    regression="bbsr",
    workflow="tfa"
)

# --------------------------------------------------
# Runtime options
# --------------------------------------------------
worker.set_run_parameters(
    num_bootstraps=20,
    random_seed=1
)

# --------------------------------------------------
# Load inputs
# --------------------------------------------------

worker.set_file_paths(
    input_dir=str(DATA_DIR),
    output_dir=str(OUT_DIR),
    expression_matrix_file="expression.tsv",
    meta_data_file="metadata.tsv",
    tf_names_file="tf_names.txt"
)

# --------------------------------------------------
# Expression format (genes × samples)
# --------------------------------------------------

worker.set_file_properties(
    expression_matrix_columns_are_genes=False,
    metadata_handler="nonbranching"
)

# --------------------------------------------------
# CRITICAL: disable TFA (no latent TF activities) (to match dynGENIE3 comparison)
# --------------------------------------------------

worker.set_tfa(tfa_driver=False)

# --------------------------------------------------
# Time-lagged design
# delTmax defines the maximum allowed regulatory delay window
# tau is the time constant in the exponential decay of how
# a value is weighted with the time delay 
# Inferelator is a multi-delay linear system
# --------------------------------------------------

worker.set_design_settings(
    timecourse_response_driver=True,
    delTmin=0,
    delTmax=200,
    tau=100
)

# --------------------------------------------------
# IMPORTANT: gold standard must NOT affect inference
# (gold standard NOT used for the inference)
# --------------------------------------------------

worker.use_no_gold_standard = True
worker.split_gold_standard_for_crossvalidation = False
worker.gold_standard_file = None

# --------------------------------------------------
# READ in the data
# --------------------------------------------------
expr = pd.read_csv(DATA_DIR / "expression.tsv", sep="\t", index_col=0)
genes = list(expr.index)
tfs = list(pd.read_csv(DATA_DIR / "tf_names.txt", header=None)[0])
tfs = [t for t in tfs if t in genes]
# --------------------------------------------------
# PRIOR (required structurally in 0.6.3)
# --------------------------------------------------
# We give a uniform prior ONLY to satisfy schema.
# It does NOT represent biological knowledge.
# But Inferelator wants it in matrix format

uniform_prior = pd.DataFrame(
    1,
    index=tfs,
    columns=genes
)

prior_file = DATA_DIR / "uniform_prior.tsv"
uniform_prior.to_csv(prior_file, sep="\t")

worker.priors_file = str(prior_file)
worker.read_priors()

# --------------------------------------------------
# RUN INFERENCE
# --------------------------------------------------

worker.run()

# --------------------------------------------------
# Load results
# --------------------------------------------------

net = pd.read_csv(
    OUT_DIR / "network.tsv.gz",
    sep="\t",
    compression="gzip"
)

# Standardize column names if needed
net.columns = [c.lower() for c in net.columns]

# Remove the self edges because there aren't any in the DREAM framework

# Expect columns like:
# regulator, target, combined_confidences

# --------------------------------------------------
# Extract TOP 10 edges
# --------------------------------------------------

top10 = net.sort_values(
    "combined_confidences",
    ascending=False
).head(10)

print("\nTOP 10 inferred TF → target edges:\n")
print(top10[["regulator", "target", "combined_confidences"]])



#  To check no use of gold_standard
# (netA["combined_confidences"] == netB["combined_confidences"]).all()
