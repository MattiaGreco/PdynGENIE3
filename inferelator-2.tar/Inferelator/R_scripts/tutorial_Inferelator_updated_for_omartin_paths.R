# Example for running Inferelator on a few test examples
# Uses the Inferelator python software installed within the conda environment "inferelator"
# with the TFA workflow and the timecourse response driver enabled
# We also include "UsefulFunctions.R" to allow a few additional utilities
# To run this on your computer, set these paths to their correct value:
# path_inferelator  path_input  path_pred
# One has to have activated the inferelator environment from the shell
####  conda activate inferelator

# Set number of genes
NGENES <- 100


# Prefix of the files with golds and time series
nomenclature="goldSigned_"

# Path for Inferelator benchmarking
path_inferelator <- "~/LOCAL/GRN_Inference/BENCHMARKING/Inferelator/"
# Contains the directories: data  results  R_scripts  Python_scripts

# Path for input data (time series expression)
path_input <- "~/GRECO/REVISION_03_2026/Nodes_100/In_out_degree_4_num_nodes_100/"
list_TS_files <- list.files(paste0(path_input,"Simulation_files_Time_Series/")) # gives us the names of the files under the given path
list_Goldstandards_files <- list.files(paste0(path_input,"Goldstandards/")) # gives us the names of the files under the given path

# Path to output predictions (importances as a file "from" "to" "strength")
path_pred <- "~/GRECO/REVISION_03_2026/Nodes_100/In_out_degree_4_num_nodes_100/Predictions_Time_Series_Inferelator/"

setwd(path_inferelator)
# First work in R
# Source "UsefulFunctions.R" for other useful functions
source("R_scripts/UsefulFunctions.R")

n_time_series <- 10
n_times   <- 21

TS_number <- numeration_of_list_files(list_TS_files)
Goldstandards_number <- numeration_of_list_files(list_Goldstandards_files)
ii <- 1
for (ii in 81:length(TS_number)){  
  print("######################################")
  print(paste("graph number",TS_number[ii]))
  print(paste("Goldstandard number",Goldstandards_number[ii]))
  print("######################################")
  path_data=paste(path_input,"Simulation_files_Time_Series/",list_TS_files[ii],sep="")
  this_graph_error <- FALSE

  # Get time series data
  # This example is of the DREAM type: perturbed basal transcription rate for first half of series
  # The time series have 21 time points and we have 10 experiments
  df <- read.table(path_data,quote="",sep="\t")
  # row 1 is "Time" followed by all gene names
  # following rows: expression vector at each time
  gene_names <- df[1,-1]
  df <- df[-1,]
  these_times <- df[1:n_times,1]
  sample_names <- unlist(lapply(seq_len(n_time_series), 
    function(i) {paste0("TS", i, "_t", these_times)} ))
  df <- df[,-1]
  expr <- t(df)
  colnames(expr) <- sample_names
  row.names(expr) <- gene_names

# Write the input files needed by inferelator into the directory data
  path_gold=paste(path_input,"Goldstandards/",list_Goldstandards_files[ii],sep="")
  gold_standard_data <- read.table(file=path_gold,sep="\t")
  colnames(gold_standard_data) <- c("regulator","target","sign")
  gold_standard_data$sign <- 1
  write.table(gold_standard_data,file = "data/gold_standard_DREAM.tsv",
    row.names = FALSE, col.names = FALSE, sep = "\t",quote = FALSE)
  write.table(expr,file = "data/expression.tsv",
    sep = "\t",quote = FALSE)
  write.table(t(gene_names),file = "data/tf_names.txt",
    row.names = FALSE,col.names = FALSE,quote = FALSE)    # Default: all genes are putative regulators
  metadata <- data.frame(sample_id = sample_names,strain = rep(paste0("TS", seq_len(n_time_series)),
    each = n_times),time = rep(these_times,times = n_time_series))    
  write.table(metadata,file = "data/metadata.tsv",
    sep = "\t",quote = FALSE,row.names = FALSE)
# Lastly, the prior matrix is required by inferelator even if not used
  genes <- rownames(expr)
  tfs   <- genes
  prior <- matrix(1L,nrow = length(tfs),ncol = length(genes),dimnames = list(tfs, genes))
  write.table(prior,file = "data/uniform_prior.tsv",
    sep = "\t",quote = FALSE,col.names = TRUE)

# Now use the shell to run Inferelator
  setwd("Python_scripts")
  my_command <- paste0("cd ",path_inferelator,"Python_scripts")
  system(my_command)
  my_command <- "python run_inferelator_with_gold_no_TFA.py"
  system("python run_inferelator_with_gold_no_TFA.py")

# Read the output network produced by Inferelator
  setwd(path_inferelator)
  setwd("results")
  my_command <- "zcat network.tsv.gz  | cut -f 1,2,3 | tail -n +2 > edges.tsv"
  system(my_command)
  file_name <- paste0("goldSigned_",TS_number[ii],"_prediction.tsv")
  file_name <- paste0(path_input,"Predictions_Time_Series_Inferelator/",file_name)
  my_command <- paste0("mv edges.tsv ",file_name)
  system(my_command)

  setwd(path_inferelator)

# There are no self interactions. Currently that is dealt with in auroc_golds_predictions.sh 
# If one is dealing with a rectangular matrix one must use the gene names.
#  colnames(weights) <- regulator_genes
#  rownames(weights) <- regulator_genes
}
